class Main 
{
  public static void main(String[] args) 
  {
        double Usdollar = 1.18; // the amount of us to euro 
        int Euros = 1; // the amount for euros 
          System.out.print(" 1 euro is equal to " + Usdollar + "Us dollars" + " this many euros" );
            
            System.out.println("1 Us dollar is equal to " + Euros);


            






  }
}